import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("введить число:");
        int arg333 = scanner.nextInt();

        toTen(arg333, 16);

        System.out.println("введить число:");
        int arg637 = scanner.nextInt();
        tenTo(arg637, 16);
        toTen(arg637, 16);

        tenTo(arg637, 2);

        tenTo(arg637, 3);

        toTen(11100111, 2);
    }

    public static void toTen(int arg, int  digit){
        System.out.println("число" + arg + "is" + digit + " в 10");
        int result = 0;
        int value = 0;
        int counter = Integer.toString(arg).length();


        for(int i= 0; i<counter; i++){
            value = arg % 10;
            result += value * Math.pow(digit, i);
            arg /= 10;

        }
        System.out.println(result);
    }
    public static void tenTo(int arg, int digit){
        System.out.println("число" + arg + "из 10 в" + digit + ":");
        String result = "";
        int value = 0;
        while (arg!=0) {
            value = arg % digit;
            result = value + result;
            arg /= digit;

        }
        System.out.println(result);
        }

}